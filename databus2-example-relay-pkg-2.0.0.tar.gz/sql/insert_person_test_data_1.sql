INSERT INTO person(first_name, last_name, birth_date)
       VALUES('balaji', 'varadaran', '1980-01-01');
INSERT INTO person(first_name, last_name, birth_date)
       VALUES('boris', 'shkolnik', '1981-02-02'),
             ('sunil', 'nagaraj', '1982-03-03');
INSERT INTO person(first_name, last_name, birth_date)
       VALUES('chavdar', 'botev', '1983-04-04'),
             ('phanindra', 'ganti', '1984-05-05'),
             ('sajid', 'topiwala', '1985-06-06'),
             ('naveen', 'somasundaram', '1984-05-05');
INSERT INTO person(first_name, last_name, birth_date)
       VALUES('greg', 'roelofs', '1985-06-06'),
             ('kapil', 'surlaker', '1986-07-07');
